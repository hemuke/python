#! /root/anaconda3/bin/python
def f():
    print('f被调用')
